﻿=== Color Newsly ===

Contributors:       mysterythemes
Tags:               blog, portfolio, news, grid-Layout, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, full-width-template, footer-widgets, rtl-language-support, theme-options, translation-ready, block-styles, wide-blocks
Requires at least:  4.7
Tested up to:       6.1.1
Requires PHP:       5.2.4
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Color Newsly is a child theme of color magazine WordPress theme specially designed for digital news, magazines, and news portal websites in general. With WordPress customizer, you can easily add a site logo, change colors, and choose layouts and fonts with instant preview. It comes with multiple pre-made demos that you can import to set up a well-designed professional website quickly. This theme has powerful features like a sticky header, category colors, a social sharing feature, a trending section, multiple layouts, and many more. Check the demo here: https://demo.mysterythemes.com/child-theme/color-newsly/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Copyright ==

Color Newsly WordPress Theme, Copyright 2023 Mystery Themes.
Color Newsly is distributed under the terms of the GNU GPL

    Screenshot Images Licence ==
        
        Credit soyfeliz2018
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/1446753

        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/1233634

        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/710514

        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/733021
        
        Credit rawpixel.com
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/1445813
        
        Credit grenny
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/1456591
        
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/62317
        
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/21031
        
        License: CC0 Public Domain
        License URL: https://pxhere.com/en/license
        Source: https://pxhere.com/en/photo/892055

== Changelog ==

= 1.0.1 = 
    * Fixed underline and key board navigation issue.
    * Fixed dynamic color issue for header and submenu.
    * Some design tweaks done. 

= 1.0.0 = 
	* Submit theme on wordpress.org trac.